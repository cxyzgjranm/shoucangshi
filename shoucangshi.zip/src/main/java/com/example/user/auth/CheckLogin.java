package com.example.user.auth;

public @interface CheckLogin {
}
