package com.example.user.auth;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

//标识注解被什么情况下所加载
@Retention(RetentionPolicy.RUNTIME)
public @interface CheckAuthorization {
    String value();
}
