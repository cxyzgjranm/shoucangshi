package com.example.user.auth;

import cn.hutool.crypto.digest.MD5;
import com.example.user.enums.ResultEnum;
import com.example.user.exception.SystemException;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

@Aspect
@Component
public class CheckLoginAspect {
    @Around("@annotation(com.example.user.auth.CheckLogin)")
    public Object checkLogin(ProceedingJoinPoint joinPoint) throws Throwable {
        checkToken();
        return joinPoint.proceed();
    }

    private void checkToken() {
        //获取request
        HttpServletRequest request = getRequest();

        String token = request.getHeader("token");
        String key = "ok";
        String x = MD5.create().digestHex16(key);
        if (!x.equals(token)) {
            throw new SystemException(ResultEnum.NOT_LOGIN.getMsg());
        }
    }

//    @Around("@annotation(com.example.user.auth.CheckAuthorization)")
//    public Object checkAuthorization(ProceedingJoinPoint joinPoint) throws Throwable {
//        // 1、首先校验是否登陆
//        checkToken();
//        // 2、判定是否拥有权限
//        // 2.1获取被AOP通知的方法上的注解
//        // 获取方法的签名
//        MethodSignature signature = (MethodSignature)joinPoint.getSignature();
//        // 获取需要判断权限的注解
//        CheckAuthorization annotation = signature.getMethod().getAnnotation(CheckAuthorization.class);
//        // 通过注解拿到配置在注解上的value值
//        String value = annotation.value();
//        // 1、登陆完后，把用户对应的权限，从user_role表中查出来，返回给前端
//        // 前端每次请求携带角色信息 member, admin
//        HttpServletRequest request = getRequest();
//        String role = request.getParameter("role");
//        // 解密token中的签名
//        if (!Objects.equals(value, role)) {
//            throw new SystemException(250, "您没有权限！！");
//        }
//        // 2、用户登陆成功后，生成的token里，可以把角色加密到token里。
//        // jwt  xxxx.xxxx.xxxx
//        return joinPoint.proceed();
//    }

    public HttpServletRequest getRequest() {
        RequestAttributes attributes = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes requestAttributes =
                (ServletRequestAttributes)attributes;
        HttpServletRequest request = requestAttributes.getRequest();
        return request;
    }
}
