package com.example.user.enums;

import lombok.Getter;

@Getter
public enum  ResultEnum {
    SUCCESS(200, "成功"),
    ERROR(500, "参数错误"),
    LOGIN_PARAM_ERROR(1, "用户名或密码为空"),
    USER_NOT(2, "用户名不存在"),
    LOGIN_ERROR(3, "用户名或密码错误"),
    NOT_LOGIN(4, "用户未登录"),
    DELETE_OK(5, "用户不存在"),
    UNREGIST(6, "用户已注销"),
    BOOK_NULL(7, "没有相关书籍"),
    BOOK_DELETED(8, "相关书籍已删除"),
    PHONE_HAS(9, "账号已注册"),
    BOOK_CONTENT_NULL(10, "没有相关书籍资料"),
    LITERATURE_NULL(11, "没有相关信息"),
    PHONE_NULL(600, "请先注册");

    Integer code;
    String msg;
    ResultEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
