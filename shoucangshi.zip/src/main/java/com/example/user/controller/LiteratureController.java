package com.example.user.controller;

import com.example.user.domain.Result;
import com.example.user.entity.LiteratureInfo;
import com.example.user.service.LiteratureInfoService;
import com.example.user.utils.ResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/literatureInfo")
public class LiteratureController {

    @Autowired
    private LiteratureInfoService service;

    //查询所有报纸新闻信息
    //分页展示
    @GetMapping("/findAllLiterature")
    public List<LiteratureInfo> findAllLiterature() {
        List<LiteratureInfo> literatureInfoList = service.getAllLiterature();
        return literatureInfoList;
    }


    //添加新闻报纸资料
    @PostMapping("/addlttInfo")
    public Result<LiteratureInfo> addLiteratureInfo(@Valid LiteratureInfo lttInfo, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            log.error(bindingResult
                    .getFieldError()
                    .getDefaultMessage());
            return ResultUtil.error(
                    bindingResult
                            .getFieldError()
                            .getDefaultMessage());
        }

        lttInfo = service.addLiteratureInfo(lttInfo);
        return ResultUtil.success(lttInfo);
    }

    //修改报纸新闻信息
    @PostMapping("/editLiteratureInfo")
    public Result<LiteratureInfo> editLiteratureInfo(LiteratureInfo literatureInfo) {
        literatureInfo = service.addLiteratureInfo(literatureInfo);
        return ResultUtil.success(literatureInfo);
    }

    //删除报纸新闻信息
    @PostMapping("/deleteLiteratureInfo")
    public Result<LiteratureInfo> deleteLiteratureInfo(LiteratureInfo literatureInfo) {
        literatureInfo = service.deleteLiteratureInfo(literatureInfo);
        return ResultUtil.success(literatureInfo);
    }

    //根据报纸的(年代)或者(新闻题目)或者（关键字）或者（年代）
    //如何进行全局搜索？****************************
    @PostMapping("/findByKey")
    public Result<String> getLiteratureByKey(@RequestParam String key) {

        //逻辑代码——————————————
        return ResultUtil.success("ok");
    }

    //获取新闻主要内容
    @PostMapping("/getContent")
    public Result<String> getLiteratureContent(String path) {

        return ResultUtil.success("ok");
    }
}
