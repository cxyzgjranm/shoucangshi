package com.example.user.controller;

import com.example.user.service.ORCService;
import com.example.user.tesseract.OcrRecognizer;
import com.example.user.utils.ImageModify;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@RestController
@RequestMapping("/tesserateOcr")
public class ORCController {
    @Autowired
    private ORCService service;

    @PostMapping("/upload")
    public String uploadfile(@RequestParam("file") MultipartFile file) {
        String valCode = null;
        String ori_name = file.getOriginalFilename();

        //文件后缀名
        String suffixBefore = ori_name.substring(0, ori_name.indexOf("."));
        String suffix = ori_name.substring(suffixBefore.length() + 1, ori_name.length());
        System.out.println(suffix);

        System.out.println(ori_name + "连接成功");
        //下载图片到本地
        service.upload(file);
        String path ="E:/shoucangshi/pics/"+ori_name;
//        String path = "E:/shoucangshi/pics/" + "trans-" + ori_name;

        //图片处理
        ImageModify.gray(path,path);
//        ImageModify.ChangeImage(ori_name);
        System.out.println(path + " OCR Test Begin......");
        try {
            valCode = new OcrRecognizer().recognizeText(new File(path), suffix);
//            valCode = new OcrRecognizer().recognizeText(new File(path), "jpg");

            System.out.println(valCode + "--------------------------");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("OCR Test End......");
        return valCode;
    }

}
