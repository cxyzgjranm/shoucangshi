package com.example.user.controller;

import cn.hutool.core.util.StrUtil;
import com.example.user.auth.CheckLogin;
import com.example.user.domain.Result;
import com.example.user.entity.UserInfo;
import com.example.user.enums.ResultEnum;
import com.example.user.exception.SystemException;
import com.example.user.pojo.UserPojo;
import com.example.user.service.UserInfoService;
import com.example.user.utils.ResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

//返回Json字符串
@RestController
@RequestMapping("/userInfo")
@Slf4j
public class UserController {

    @Autowired
    private UserInfoService service;

    //查询所有用户信息
//    @GetMapping("/findAllUserInfo")
//    public List<UserInfo> getAllUserInfo() {
//        List<UserInfo> userInfoList = service.getAllUserInfo();
//        return userInfoList;
//    }

    //Test
    @PostMapping("/getUserName")
    public String getUserName(@RequestBody UserInfo userInfo) {
        UserPojo userPojo = service.findByTelenum(userInfo);
        return userPojo.getUserName();
    }


    //新增用户信息(注册时)
    @PostMapping("/addUserInfo")
//    public Result<UserInfo> addUserInfo(@RequestBody @Valid UserInfo userInfo, BindingResult bindingResult) {
    public Result<UserPojo> addUserInfo(@RequestBody @Valid UserInfo userInfo, BindingResult bindingResult) {

        if (bindingResult.hasErrors()) {
            //记录日志
            //logback实现logback配置信息，每天自动生成日期文件名的日志（日期之前删除）**********************
            log.error(bindingResult
            .getFieldError()
            .getDefaultMessage());
            return ResultUtil.error(
                    bindingResult
                    .getFieldError()
                    .getDefaultMessage()
            );
        }
        UserPojo userPojo = service.addUserInfo(userInfo);
        return ResultUtil.success(userPojo);
    }

    //登录（根据用户名称和密码）
    @PostMapping("/login")
    public Result<Map<String, String>> findUserByNameAndPassword(@RequestParam String phoneNum, @RequestParam String loginPassword) {
        if (StrUtil.isEmpty(phoneNum) || StrUtil.isEmpty(loginPassword)) {
            throw new SystemException(ResultEnum.LOGIN_PARAM_ERROR.getMsg());
        }
        Map<String, String> token = service.findUserByNameAndPassword(phoneNum, loginPassword);
//        UserInfo userInfo = service.findUserByNameAndPassword(phoneNum, loginPassword);

        //返回什么？********************token标志
        return ResultUtil.success(token);
    }

    //修改信息时
    @PostMapping("/editUserInfo")
//    @CheckLogin
    public Result<UserPojo> editByUserName(@RequestBody UserInfo userInfo) {
        if (userInfo.getUserPassword() == null
                && userInfo.getUserName() == null
                && userInfo.getUserPortrait() == null) {
            UserPojo userPojo = service.findByTelenum(userInfo);
            return ResultUtil.success(null);
        }

        UserPojo userPojo = service.editUserInfo(userInfo);
        return ResultUtil.success(100, "修改成功", userPojo);
    }

    //删除用户信息(注销)
    @PostMapping("/deleteUserInfo")
    @CheckLogin
//    public Result<UserInfo> deleteUserInfo(@RequestBody UserInfo userInfo) {
    public Result<UserPojo> deleteUserInfo(@RequestBody UserInfo userInfo) {

        UserPojo userPojo = service.deleteUserInfo(userInfo);
        return ResultUtil.success(userPojo);
    }

}
