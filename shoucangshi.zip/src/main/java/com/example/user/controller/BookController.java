package com.example.user.controller;

import cn.hutool.core.codec.Base64;
import cn.hutool.http.server.HttpServerResponse;
import com.example.user.domain.Result;
import com.example.user.entity.BookInfo;
import com.example.user.enums.ResultEnum;
import com.example.user.exception.SystemException;
import com.example.user.pojo.BookPojo;
import com.example.user.service.BookInfoService;
import com.example.user.utils.BookUtil;
import com.example.user.utils.ResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.Base64Utils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageOutputStream;
import javax.validation.Valid;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

@Configuration
@RestController
@RequestMapping("/bookInfo")
@Slf4j
public class BookController {

    @Autowired
    private BookInfoService service;

    //查询所有图书信息
    //分页展示？
    @GetMapping("/findAllBookInfo")
//    public Result<List<BookInfo>> getAllBookInfo() {
    public Result<List<BookPojo>> getAllBookInfo() {

        List<BookPojo> bookInfoList = service.getAllBookInfo();
        return ResultUtil.success(bookInfoList);
    }

    //添加图书信息
    @PostMapping("/addBookInfo")
//    public Result<BookInfo> addBookInfo(@RequestBody @Valid BookInfo bookInfo, BindingResult bindingResult) {
    public Result<BookInfo> addBookInfo(@RequestBody @Valid BookInfo bookInfo, BindingResult bindingResult) {

        if (bindingResult.hasErrors()) {
            //记录日志
            log.error(bindingResult
            .getFieldError()
            .getDefaultMessage());
            return ResultUtil.error(bindingResult
            .getFieldError()
            .getDefaultMessage());
        }

        bookInfo = service.addBookInfo(bookInfo);
        return ResultUtil.success(bookInfo);
    }

    //根据书名或作者查找书籍
    @PostMapping("/findBookByNameOrAuthor")
//    public Result<List<BookInfo>> findBookByName(@RequestParam String nameOrAuthor) {
    public Result<List<BookPojo>> findBookByName(@RequestParam String nameOrAuthor) {

        List<BookPojo> bookInfoList = service.findBookInfoByName(nameOrAuthor);
//        System.out.println(bookInfoList);
        return ResultUtil.success(bookInfoList);
    }

    //删除书籍信息
    @PostMapping("/deleteBookInfo")
    public Result<BookInfo> deleteBookInfo(@RequestBody BookInfo bookInfo) {
        bookInfo = service.deleteBookInfo(bookInfo);
        return ResultUtil.success(bookInfo);
    }

    //修改图书信息
    @PostMapping("/editBookInfo")
    public Result<BookInfo> editByBookName(@RequestBody BookInfo bookInfo) {
//    public Result<BookPojo> editByBookName(@RequestBody BookInfo bookInfo) {

        bookInfo = service.addBookInfo(bookInfo);
        return ResultUtil.success(bookInfo);
    }

    //传输书籍正文内容


    //获取书的主要内容
    @PostMapping("/getBookContent")
//    public Result<String> getBookContent(@RequestParam String bookName) {
    public Result<List<String>> getBookContent(@RequestParam String bookName) {

        //分页展示
//        String upload = service.upload(bookName);
        List<String> upload = service.upload(bookName);
//        BookInfo bookInfo = new BookInfo();
//        return ResultUtil.success("nihao");
        return ResultUtil.success(upload);
    }

    //根据书的内容查书的信息
    @PostMapping("/getNameByContent")
//    public Result<List<BookInfo>> getByContent(@RequestParam String content) {
    public Result<List<BookPojo>> getByContent(@RequestParam String content) {

        List<BookPojo> bookList = service.getInfoByContent(content);
        if (bookList.size() == 0) {
            return ResultUtil.error(ResultEnum.BOOK_CONTENT_NULL.getMsg());
        }
        return ResultUtil.success(bookList);
    }

    @PostMapping("/getInfoBySort")
    public Result<List<BookPojo>> getBookInfoBySort(@RequestParam String sort) {
        List<BookPojo> bookPojos = service.getBookInfoBySort(sort);
        return ResultUtil.success(bookPojos);

    }




    //报纸的部分（暂放在书的数据库里面）
//    @PostMapping("/getLiteraturePic")
//    public String getLiteraturePic(@RequestParam String bookName) {
//        List<BookPojo> bookPojoList = service.getLiteraturePic(bookName);
//        List<File> fileList = new ArrayList<>();
//        String path = BookUtil.PIC_PATH;
//        FileInputStream fis = null;
//        ByteArrayOutputStream bos = null;
//        String result = null;
////        OutputStream bos = null;
//        StringBuffer buffer = new StringBuffer();
//        for (BookPojo pojo : bookPojoList) {
//            String picture = pojo.getBPicture();
//            String realPath = path + picture;
//            File file = new File(realPath);
//            if (!file.exists()) {
//                throw new SystemException("没有保存相关图片");
//            } else {
////                fileList.add(file);
////            }
//                try {
//                    fis = new FileInputStream(file);
//                    bos = new ByteArrayOutputStream();
////                    byte[] b = new byte[1024];
//                    byte[] b = new byte[1024];
//                    int len = 0;
//                    while ((len = fis.read(b)) != -1) {
//                        bos.write(b, 0, len);
//                        bos.flush();
//                        buffer.append(new String(b, 0, len));
//                        System.out.println(buffer);
////                        result = Base64Utils.encodeToString(b);
//                    }
////                    InputStreamReader reader = new InputStreamReader(fis, "utf-8");
////                    FileOutputStream fop = new FileOutputStream(file);
////                    OutputStreamWriter writer = new OutputStreamWriter(fop, "utf-8");
//                } catch (FileNotFoundException e) {
//                    e.printStackTrace();
//                } catch (UnsupportedEncodingException e) {
//                    e.printStackTrace();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                } finally {
//                    try {
//                        bos.close();
//                        fis.close();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//
//                }
//            }
////        return ResultUtil.success(fileList);
//        }
//        System.out.println(buffer.toString());
//        return buffer.toString();
//    }
////        return bos.toByteArray();
////        System.out.println(bos.toByteArray()+"上传成功");
////    }







    @PostMapping("/getLiteraturePic")
    public byte[] getLiteraturePic(@RequestParam String bookName) {
        List<BookPojo> bookPojoList = service.getLiteraturePic(bookName);
//        System.out.println(bookPojoList.size());
        String path = BookUtil.PIC_PATH;

        ByteArrayOutputStream bs = new ByteArrayOutputStream();
        ImageOutputStream imOut = null;

        for (BookPojo pojo : bookPojoList) {
            String picture = pojo.getBPicture();
            String suffixBefore = picture.substring(0, picture.indexOf("."));
            String suffix = picture.substring(suffixBefore.length() + 1, picture.length());
            System.out.println(suffix);

            String realPath = path + picture;
            try {
                BufferedImage bufferedImage = ImageIO.read(new URL("file:///"+realPath));
                System.out.println(bufferedImage);
                imOut = ImageIO.createImageOutputStream(bs);
                ImageIO.write(bufferedImage, suffix, imOut);
                return null;
            } catch (IOException e) {
                e.printStackTrace();
            }finally {
                if (bs != null) {
                    try {
                        bs.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (imOut != null) {
                    try {
                        imOut.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return null;

    }










}
