package com.example.user.pojo;

import lombok.Data;

@Data
public class LiteraturePojo {
    private String lrtId;
    //题目
    private String lrtTitle;
    //作者
    private String lrtAuthor;
    //图片
    private String lrtPic;
    //正文
    private String lrtContent;
    //收藏馆
    private String lrtAddress;
    //分类
    private String lrtClassification;
    //出版年代
    private String lrtPublishAge;
}
