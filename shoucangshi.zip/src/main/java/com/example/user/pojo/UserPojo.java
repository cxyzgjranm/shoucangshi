package com.example.user.pojo;

import lombok.Data;

@Data
public class UserPojo {
    private String userId;
    private String userTelenum;
    private String userName;
}
