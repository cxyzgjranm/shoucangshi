package com.example.user.pojo;

import lombok.Data;

@Data
public class BookPojo {
    private String bId;
    //书名
    private String bName;
    //书封面
    private String bPicture;
    //作者
    private String bAuthor;
    //出版年代
    private String bPublishAge;
    //简介
    private String bDescription;
    //出版者
    private String bPublisher;
    //分类
    private String bClassification;
    //收藏地址
    private String bAddress;
    //丛书名
    private String bSeriesName;
}
