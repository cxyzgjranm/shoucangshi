package com.example.user.exception;

import lombok.Getter;

@Getter
public class SystemException extends RuntimeException {
    private Integer code;

    public SystemException(Integer code, String msg) {
        super(msg);
        this.code = code;
    }

    public SystemException(String msg) {
        super(msg);
    }
}
