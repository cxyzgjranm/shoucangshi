package com.example.user.exception;

import com.example.user.domain.Result;
import com.example.user.utils.ResultUtil;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class SystemExceptionHandler {
    @ExceptionHandler(SystemException.class)
    public Result handlerException(SystemException e) {
        return ResultUtil.error(e.getMessage());
    }
}
