package com.example.user.service;

import cn.hutool.core.util.ObjectUtil;
import com.example.user.entity.LiteratureInfo;
import com.example.user.enums.ResultEnum;
import com.example.user.exception.SystemException;
import com.example.user.repository.LiteratureInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
public class LiteratureInfoService {

    @Autowired
    private LiteratureInfoRepository repository;

    public LiteratureInfo addLiteratureInfo(LiteratureInfo lttInfo) {
        if (lttInfo.getLrtId() == null || "".equals(lttInfo.getLrtId())) {
            lttInfo.setLrtId(UUID.randomUUID().toString());
            Date date = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String dateTime = sdf.format(date);
            lttInfo.setLrtDate(dateTime);
        }
        lttInfo.setIsDeleted(0);
        lttInfo = repository.save(lttInfo);
        return lttInfo;
    }

    public List<LiteratureInfo> getAllLiterature() {
        List<LiteratureInfo> literatureInfoList = repository.findAllInfo();
        return literatureInfoList;
    }

    public LiteratureInfo deleteLiteratureInfo(LiteratureInfo literatureInfo) {
        LiteratureInfo literatureInfo1 = repository.findByLrtId(literatureInfo.getLrtId());
        if (ObjectUtil.isEmpty(literatureInfo1)) {
            throw new SystemException(ResultEnum.LITERATURE_NULL.getMsg());
        }
        literatureInfo1.setIsDeleted(1);
        literatureInfo = repository.save(literatureInfo1);
        return literatureInfo;
    }

//    public LiteratureInfo deleteLiteratureInfo(LiteratureInfo literatureInfo) {
//
//    }
}
