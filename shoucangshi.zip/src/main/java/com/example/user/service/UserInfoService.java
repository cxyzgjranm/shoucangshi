package com.example.user.service;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.crypto.digest.MD5;
import com.example.user.entity.UserInfo;
import com.example.user.enums.ResultEnum;
import com.example.user.exception.SystemException;
import com.example.user.pojo.UserPojo;
import com.example.user.repository.UserInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class UserInfoService {

    @Autowired
    private UserInfoRepository repository;

    public List<UserInfo> getAllUserInfo() {
        List<UserInfo> userInfoList = repository.findAll();
        return userInfoList;
    }

    //    public UserInfo deleteUserInfo(UserInfo userInfo) {
    public UserPojo deleteUserInfo(UserInfo userInfo) {

        //判断用户是否存在
        UserInfo userInfo1 = repository.findByUserTelenum(userInfo.getUserTelenum());
        if (ObjectUtil.isEmpty(userInfo1)) {
            throw new SystemException(ResultEnum.DELETE_OK.getMsg());
        } else if (userInfo1.getIsDeleted() == 1) {
            throw new SystemException(ResultEnum.UNREGIST.getMsg());
        }
        userInfo1.setIsDeleted(1);
        userInfo = repository.save(userInfo1);

        UserPojo userPojo = new UserPojo();
        userPojo.setUserId(userInfo.getUserId());
        userPojo.setUserName(userInfo.getUserName());
        userPojo.setUserTelenum(userInfo.getUserTelenum());

        return userPojo;

    }

    //    public UserInfo addUserInfo(UserInfo userInfo) {
    public UserPojo addUserInfo(UserInfo userInfo) {

        UserInfo userInfo1 = repository.findByUserTelenum(userInfo.getUserTelenum());
        if (!ObjectUtil.isEmpty(userInfo1)) {
            throw new SystemException(ResultEnum.PHONE_HAS.getMsg());
        }
        if (userInfo.getUserId() == null || "".equals(userInfo.getUserId())) {
            Date date = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String dateTime = sdf.format(date);
            userInfo.setUserId(UUID.randomUUID().toString());
            //密码在android加密
            userInfo.setUserPassword(
                    MD5.create().digestHex16(userInfo.getUserPassword()));
            userInfo.setUserRegistdate(dateTime);
        }
        userInfo.setIsDeleted(0);
        userInfo = repository.save(userInfo);

        UserPojo userPojo = new UserPojo();
        userPojo.setUserId(userInfo.getUserId());
        userPojo.setUserName(userInfo.getUserName());
        userPojo.setUserTelenum(userInfo.getUserTelenum());

        return userPojo;
    }

    public Map<String, String> findUserByNameAndPassword(String phoneNum, String password) throws SystemException {
        //判断用户是否存在
        UserInfo userInfo = repository.findByUserTelenum(phoneNum);
//        System.out.println(userInfo);
        if (ObjectUtil.isEmpty(userInfo)) {
            throw new SystemException(ResultEnum.USER_NOT.getMsg());
        }
            //校验密码
        String dbPassword = userInfo.getUserPassword();
        String userPassword = MD5.create().digestHex16(password);
        if (!dbPassword.equals(userPassword)) {
            throw new SystemException(ResultEnum.LOGIN_ERROR.getMsg());
        }
        //无状态应用
//        如何在配置信息里面更改key值
        Map<String, String> result = new HashMap<>();
        String key = "ok";
        String token = MD5.create().digestHex16(key);
        result.put("token", token);
        return result;


    }

    public UserPojo findByTelenum(UserInfo userInfo) {
        UserPojo userPojo = new UserPojo();
        userInfo = repository.findByUserTelenum(userInfo.getUserTelenum());
        if (ObjectUtil.isEmpty(userInfo)) {
            throw new SystemException(ResultEnum.PHONE_NULL.getCode(), ResultEnum.PHONE_NULL.getMsg());
        }

        userPojo.setUserName(userInfo.getUserName());
        return userPojo;
    }

    //    public UserInfo editUserInfo(UserInfo userInfo) {
    public UserPojo editUserInfo(UserInfo userInfo) {

        UserInfo userInfo1 = repository.findByUserTelenum(userInfo.getUserTelenum());
        System.out.println(userInfo1);
        if (ObjectUtil.isEmpty(userInfo1)) {
            throw new SystemException(ResultEnum.PHONE_NULL.getMsg());
        }
        userInfo.setUserId(userInfo1.getUserId());
        if (userInfo.getUserName() == null) {
            userInfo.setUserName(userInfo1.getUserName());
        } else {
            userInfo.setUserName(userInfo.getUserName());
        }
        if (userInfo.getUserPortrait() == null) {
            userInfo.setUserPortrait(userInfo1.getUserPortrait());
        } else {
            userInfo.setUserPortrait(userInfo.getUserPortrait());
        }
        userInfo.setUserRegistdate(userInfo1.getUserRegistdate());
        userInfo.setIsDeleted(0);
        if (userInfo.getUserPassword() != null || !"".equals(userInfo.getUserPassword())) {
            userInfo.setUserPassword(
                    MD5.create().digestHex16(userInfo.getUserPassword()));
        } else {
            userInfo.setUserPassword(userInfo1.getUserPassword());
        }
        userInfo = repository.save(userInfo);

        UserPojo userPojo = new UserPojo();
        userPojo.setUserId(userInfo.getUserId());
        userPojo.setUserName(userInfo.getUserName());
        userPojo.setUserTelenum(userInfo.getUserTelenum());

        return userPojo;
    }
}
