package com.example.user.service;

import cn.hutool.core.util.ObjectUtil;
import com.example.user.entity.BookInfo;
import com.example.user.enums.ResultEnum;
import com.example.user.exception.SystemException;
import com.example.user.pojo.BookPojo;
import com.example.user.repository.BookInfoRepository;
import com.example.user.utils.BookUtil;
import com.example.user.utils.IndexUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class BookInfoService {

    @Autowired
    private BookInfoRepository repository;

    //    public List<BookInfo> getAllBookInfo() {
    public List<BookPojo> getAllBookInfo() {

        List<BookInfo> bookInfoList = repository.findAllInfo();

        List<BookPojo> bookPojoList = new ArrayList<>();
        for (BookInfo bookInfo : bookInfoList) {
            BookPojo bookPojo = bookChange(bookInfo);
            bookPojoList.add(bookPojo);
        }

        return bookPojoList;
    }

    //添加书籍信息
    public BookInfo addBookInfo(BookInfo bookInfo) {
//    public BookPojo addBookInfo(BookInfo bookInfo) {

        if (bookInfo.getBId() == null || "".equals(bookInfo.getBId())) {
            bookInfo.setBId(UUID.randomUUID().toString());
        }
        bookInfo.setIsDeleted(0);
        bookInfo = repository.save(bookInfo);

//        BookPojo bookPojo = bookChange(bookInfo);

        return bookInfo;
    }

    //    public List<BookInfo> findBookInfoByName(String nameOrAuthor) {
    public List<BookPojo> findBookInfoByName(String nameOrAuthor) {

        List<BookInfo> bookInfoList1 = repository.findByBName(nameOrAuthor);
        List<BookInfo> bookInfoList2 = repository.findByBAuthor(nameOrAuthor);
        List<BookInfo> bookInfoList3 = repository.findByBSeriesName(nameOrAuthor);
        List<BookPojo> bookInfoList = new ArrayList<>();
        if (bookInfoList1.isEmpty() && bookInfoList2.isEmpty() && bookInfoList3.isEmpty()) {
//            throw new SystemException(ResultEnum.BOOK_NULL.getMsg());
            System.out.println("不能根据书名和作者或者丛书名查到");
        } else if (bookInfoList1.isEmpty() && !bookInfoList2.isEmpty() && bookInfoList3.isEmpty()) {
            for (BookInfo bookInfo : bookInfoList2) {
                BookPojo bookPojo = bookChange(bookInfo);
                bookInfoList.add(bookPojo);
            }
        } else if (!bookInfoList1.isEmpty() && bookInfoList2.isEmpty() && bookInfoList3.isEmpty()) {
            for (BookInfo bookInfo : bookInfoList1) {
                BookPojo bookPojo = bookChange(bookInfo);
                bookInfoList.add(bookPojo);
            }
        } else if (bookInfoList1.isEmpty() && bookInfoList2.isEmpty() && !bookInfoList3.isEmpty()) {
            for (BookInfo bookInfo : bookInfoList3) {
                BookPojo bookPojo = bookChange(bookInfo);
                bookInfoList.add(bookPojo);
            }
        }
//        System.out.println(bookInfoList);
        return bookInfoList;
    }

    public BookInfo deleteBookInfo(BookInfo bookInfo) {
        //判断书籍信息是否存在
        BookInfo bookInfo1 = repository.findByBId(bookInfo.getBId());
        System.out.println(bookInfo1);
        if (ObjectUtil.isEmpty(bookInfo1)) {
            throw new SystemException(ResultEnum.BOOK_DELETED.getMsg());
        }
        bookInfo1.setIsDeleted(1);
        bookInfo = repository.save(bookInfo1);
        return bookInfo;
    }

//    public String upload(String bookName) {
////        String bookPath = bookInfo.getBLocation();
//        List<BookInfo> bookList = repository.findByBName(bookName);
////        System.out.println(bookList);
//        StringBuffer content = new StringBuffer();
//        for (BookInfo bookInfo : bookList) {
//            String realPath = BookUtil.BOOK_PATH_CONTENT + bookInfo.getBLocation();
////            System.out.println(realPath);
//            File file = new File(realPath);
//            if (!file.exists()) {
//                throw new SystemException(ResultEnum.BOOK_CONTENT_NULL.getMsg());
//            }
////            StringBuffer content = new StringBuffer();
//            try {
//                String s = "";
//                InputStreamReader in = new InputStreamReader(new FileInputStream(file), "UTF-8");
//                BufferedReader br = new BufferedReader(in);
//                while ((s = br.readLine()) != null) {
//                    content = content.append(s);
//                }
////            return content.toString();
//            } catch (UnsupportedEncodingException e) {
//                e.printStackTrace();
//            } catch (FileNotFoundException e) {
//                e.printStackTrace();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//        return content.toString();
//
//    }


    public List<BookPojo> getInfoByContent(String content) {

        List<BookPojo> bookList = new ArrayList<>();
        BookInfo bookInfo = null;
        IndexUtil util = new IndexUtil();
        List<BookPojo> bookList1 = findBookInfoByName(content);
        bookList.addAll(bookList1);
        try {
            //索引库管理
//            util.indexCreate();//要实现加载类时只加载一次
            List<String> list = util.indexSearch(content);
            util.mergeIndex();
            if (list.isEmpty()) {
                System.out.println("全文检索没有内容");
            }

            for (String location : list) {
                bookInfo = repository.findByBLocation(location);
                BookPojo bookPojo = bookChange(bookInfo);
                if (!bookList.contains(bookPojo)) {
                    bookList.add(bookPojo);
                }
            }
//            List<BookPojo> bookList1 = findBookInfoByName(content);
//            bookList.addAll(bookList2);
        }
//        catch (IOException e) {
//            e.printStackTrace();
//        }
        catch (Exception e) {
            e.printStackTrace();
        }
//        finally {
//            try {
//                util.deleteAll();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
        return bookList;
    }


    //转化为BookPojo类型
    public BookPojo bookChange(BookInfo bookInfo) {
        BookPojo bookPojo = new BookPojo();
        bookPojo.setBAddress(bookInfo.getBAddress());
        bookPojo.setBAuthor(bookInfo.getBAuthor());
        bookPojo.setBClassification(bookInfo.getBClassification());
        bookPojo.setBDescription(bookInfo.getBDescription());
        bookPojo.setBId(bookInfo.getBId());
        bookPojo.setBName(bookInfo.getBName());
        bookPojo.setBPicture(bookInfo.getBPicture());
        bookPojo.setBPublishAge(bookInfo.getBPublishAge());
        bookPojo.setBPublisher(bookInfo.getBPublisher());
        bookPojo.setBSeriesName(bookInfo.getBSeriesName());
        return bookPojo;
    }

    public List<BookPojo> getBookInfoBySort(String sort) {
        List<BookInfo> bookInfos = repository.findByBClassification(sort);
        List<BookPojo> bookPojoList = new ArrayList<>();
        for (BookInfo bookInfo : bookInfos) {
            BookPojo bookPojo = new BookPojo();
            bookPojo = bookChange(bookInfo);
            bookPojoList.add(bookPojo);
        }
        return bookPojoList;
    }

    //如何进行全局搜索

    //不能使用Info对象接收，或者传送数据，POJO类






    //对书籍进行分章节查询
    public List<String> upload(String bookName) {
        List<BookInfo> bookList = repository.findByBName(bookName);
        List<String> contentList = new ArrayList<>();
////        System.out.println(bookList);
        StringBuffer content = new StringBuffer();
        for (BookInfo bookInfo : bookList) {
            String realPath = BookUtil.BOOK_PATH_CONTENT + bookInfo.getBLocation();
//            System.out.println(realPath);
            File file = new File(realPath);
            if (!file.exists()) {
                throw new SystemException(ResultEnum.BOOK_CONTENT_NULL.getMsg());
            }
//            StringBuffer content = new StringBuffer();
            try {
                String s = "";
                InputStreamReader in = new InputStreamReader(new FileInputStream(file), "UTF-8");
                BufferedReader br = new BufferedReader(in);
                while ((s = br.readLine()) != null) {
                    content = content.append(s);
                }



                String [] paragraph = content.toString().split("——");
//                System.out.println(tRegex);
                for(int i = 1 ; i<paragraph.length ; i++)
                {
//                    System.out.println("----"+paragraph[i]);
                    contentList.add("第"+i+"章"+"          "+paragraph[i]);
                }



//            return content.toString();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return contentList;

    }

    public List<BookPojo> getLiteraturePic(String bookName) {
        List<BookInfo> bookList = repository.findByBName(bookName);
        List<BookPojo> pojoList = new ArrayList<>();
        for (BookInfo bookInfo : bookList) {
            BookPojo bookPojo = bookChange(bookInfo);
            pojoList.add(bookPojo);
        }
        return pojoList;
    }
}
