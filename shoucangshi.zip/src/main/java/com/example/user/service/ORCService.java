package com.example.user.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@Service
public class ORCService {
    public String upload(MultipartFile file) {
        if (file.isEmpty()) {
            return "File Not Exists";
        }

        String ori_name = file.getOriginalFilename();
        String path = "E:/shoucangshi/pics/"+ori_name;
        System.out.println(path);
        System.out.println("保存成功");

        File curr_file = new File(path);

        if (!curr_file.getParentFile().exists()) {
            curr_file.getParentFile().mkdirs();
        }
        try {
            file.transferTo(curr_file);
        } catch (IOException e) {
            e.printStackTrace();
            return "Error";
        }

        return "Succeed";
    }
}
