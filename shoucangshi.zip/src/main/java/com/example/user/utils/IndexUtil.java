package com.example.user.utils;

import org.apache.commons.io.FileUtils;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.cjk.CJKAnalyzer;
import org.apache.lucene.analysis.cn.smart.SmartChineseAnalyzer;
import org.apache.lucene.analysis.core.KeywordAnalyzer;
import org.apache.lucene.analysis.core.SimpleAnalyzer;
import org.apache.lucene.analysis.core.WhitespaceAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.document.*;
import org.apache.lucene.index.*;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.*;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class IndexUtil {

    static {
        try {
            judge();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    //判断是否创建索引库
    public static final void judge() throws IOException {
        String bookPath = BookUtil.BOOK_PATH;

        //判断文件夹是否为空
        File file = new File(bookPath);
        if (file.isDirectory()) {
            String[] files = file.list();
            if (file.length() == 0) {
                indexCreate();
            }
        }
    }


    //创建索引库
    public static void indexCreate() throws IOException {

//        String indexPath = BookUtil.INDEX_PATH;
        String bookPath = BookUtil.BOOK_PATH;

        IndexWriter writer = null;
        try {
            //指定索引库存放的路径
            Directory directory = getDirectory();
            //创建一个标准分析器
            //中文分析器
//            Analyzer analyzer = new SmartChineseAnalyzer();
            //创建indexWriterConfig对象
//            IndexWriterConfig config = new IndexWriterConfig(analyzer);
            //创建indexWriter对象
//            writer = new IndexWriter(directory, config);
            writer = getIndexWriter(directory);
            //原始文件路径
            File dir = new File(bookPath);
            for (File f : dir.listFiles()) {
                //文件名
                String fileName = f.getName();
                //文件内容
                String fileContent = FileUtils.readFileToString(f);
                //文件路径
                String filePath = f.getAbsolutePath();
                //文件大小
                long fileSize = FileUtils.sizeOf(f);

//                System.out.println("文件名"+fileName+"\n"+"文件内容"+fileContent+"\n"+"文件位置"+filePath+"\n"+"文件大小"+fileSize);

                //创建文件名域（域名称，域内容，是否存储）
                Field fileNameField = new StringField("fileName", fileName, Field.Store.YES);
                //内容域
                Field fileContentField = new TextField("fileContent", fileContent, Field.Store.YES);
                //文件路径域
                Field filePathField = new StringField("path", filePath, Field.Store.YES);
                //文件大小域
                Field fileSizeField = new FloatDocValuesField("size", fileSize);

                //创建document对象
                Document document = new Document();
                document.add(fileNameField);
                document.add(fileContentField);
                document.add(filePathField);
                document.add(fileSizeField);

                //创建索引，写入索引库
                writer.addDocument(document);

            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally{
            if (writer != null) {
                writer.close();
            }
        }


    }
    //搜索索引
    public List<String> indexSearch(String content) {
        Directory directory = null;
        DirectoryReader dReader = null;
        List<String> list = null;
        try {
            //索引硬盘存储路径
            directory = getDirectory();
            //读取索引
            dReader = DirectoryReader.open(directory);
            //创建索引检索对象
            IndexSearcher searcher = new IndexSearcher(dReader);
            //指定分词技术，这里采用的语言处理模块要和创建索引的时候一致，否则检索的结果很不理想
//            Analyzer analyzer = new SmartChineseAnalyzer();
            Analyzer analyzer = new StandardAnalyzer();
            //创建查询query，搜索词为content
            QueryParser parse = new QueryParser("fileContent", analyzer);
            Query query = parse.parse(content);
            //检索索引，获取符合条件的前10条记录
//            TopDocs topDocs = searcher.search(query, 10);
//            if (topDocs == null) {
//                System.out.println("无符合记录");
//            }
//            if (topDocs != null) {
//                System.out.println("总共查找到 " +  topDocs.totalHits + " 条符合条件的记录");
//                //循环输出记录内容
//                for (int i = 0; i < topDocs.scoreDocs.length; i++) {
//                    Document doc = searcher.doc(topDocs.scoreDocs[i].doc);
//                    System.out.println("第" + (i + 1) + "条内容为--\tname:\t" + doc.get("fileName") + "\tcontent:\t" + doc.get("fileContent"));
//                }
//            }

            //文字高亮显示
//            QueryScorer scorer = new QueryScorer(query);
//            Fragmenter fragmenter = new SimpleSpanFragmenter(scorer);
//            SimpleHTMLFormatter simpleHTMLFormatter = new SimpleHTMLFormatter("<b><font color='red>'", "</font></b>");
//            Highlighter highlighter = new Highlighter(simpleHTMLFormatter, scorer);
//            highlighter.setTextFragmenter(fragmenter);




            TopScoreDocCollector collector = TopScoreDocCollector.create(5, 2);
            //5,根据seacher搜索
            searcher.search(query,collector);
            ScoreDoc[] scoreDocs=collector.topDocs().scoreDocs;

            list = new ArrayList();

            if (scoreDocs.length == 0) {
                System.out.println("无记录符合");
            }
            for (ScoreDoc sd:scoreDocs){
                //6:根据seacher和scoredoc对象获取具体的document对象
                Document doc=searcher.doc(sd.doc);
                while (!list.contains(doc.get("fileName"))) {
                    list.add(doc.get("fileName"));
                }
                System.out.println(doc.get("fileName")+"---------"+doc.get("path"));
            }


//            for (ScoreDoc scoreDoc : scoreDocs) {
//                Document doc = searcher.doc(scoreDoc.doc);
//                System.out.println(doc.get("fileName"));
//                String desc = doc.get("fileContent");
//                if (desc != null) {
//                    TokenStream tokenStream = analyzer.tokenStream("fileContent", new StringReader(desc));
//                    /**
//                     * getBestFragment方法用于输出摘要（即权重大的内容）
//                     */
//                    System.out.println(highlighter.getBestFragment(tokenStream, desc));
//                }
//            }




            //关闭资源
            dReader.close();
            directory.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    //分词器
    public void analyzerStudy(String str) throws IOException {
        //需要处理的测试字符串
//        String str = "这是一个分词器测试程序，希望大家继续关注我的个人系列博客：基于Lucene的案例开发，这里加一点带空格的标签 LUCENE java 分词器";
        Analyzer analyzer = null;
        //标准分词器，如果用来处理中文，和ChineseAnalyzer有一样的效果，这也许就是之后的版本弃用ChineseAnalyzer的一个原因
        analyzer = new SmartChineseAnalyzer();
//        //第三方中文分词器，有下面2中构造方法。
//        analyzer = new IKAnalyzer();
//        analyzer = new IKAnalyzer(false);
//        analyzer = new IKAnalyzer(true);
        //空格分词器，对字符串不做如何处理
        analyzer = new WhitespaceAnalyzer();
        //简单分词器，一段一段话进行分词
        analyzer = new SimpleAnalyzer();
        //二分法分词器，这个分词方式是正向退一分词(二分法分词)，同一个字会和它的左边和右边组合成一个次，每个人出现两次，除了首字和末字
        analyzer = new CJKAnalyzer();
        //关键字分词器，把处理的字符串当作一个整体
        analyzer = new KeywordAnalyzer();

        //使用分词器处理测试字符串
        StringReader reader = new StringReader(str);
        TokenStream tokenStream  = null;
        try {
            tokenStream = analyzer.tokenStream("", reader);
            tokenStream.reset();
        } catch (IOException e) {
            e.printStackTrace();
        }
        CharTermAttribute term = tokenStream.getAttribute(CharTermAttribute.class);
        int l = 0;
        //输出分词器和处理结果
        System.out.println(analyzer.getClass());
        while(tokenStream.incrementToken()){
            System.out.print(term.toString() + "|");
            l += term.toString().length();
            //如果一行输出的字数大于30，就换行输出
            if (l > 30) {
                System.out.println();
                l = 0;
            }
        }
    }

    //搜索
    public void queryStudy(String sousuoci) throws ParseException {
        //Query过程中使用的分词器
        Analyzer analyzer = new SmartChineseAnalyzer();
        //搜索词
//        String keyValue = "基于lucene的案例开发";
//		keyValue = "基于lucene的案例开发 更多内容请访问：http://blog.csdn.net/xiaojimanman/article/category/2841877";
        //将搜索词进行下转义，如果搜索词中没有lucene中的特殊字符，可以不进行转义
        String key = QueryParser.escape(sousuoci);
        //单个搜索域
        String field = "fileContent";
        //多个搜索域
        String []fields = {"fileName" , "fileContent"};
        Query query = null;

        //对单个域构建查询语句
        QueryParser parse = new QueryParser(field, analyzer);
        query = parse.parse(key);
        System.out.println(QueryParser.class);
        System.out.println(query.toString());
        System.out.println("--------------------------------");

        //对多个域创建查询语句
        MultiFieldQueryParser parse1 = new MultiFieldQueryParser(fields, analyzer);
        query = parse1.parse(key);
        System.out.println(MultiFieldQueryParser.class);
        System.out.println(query.toString());
        System.out.println("--------------------------------");

        //词条搜索
        query = new TermQuery(new Term(field, key));
        System.out.println(query.getClass());
        System.out.println(query.toString());
        System.out.println("--------------------------------");

        //前缀搜索
        query = new PrefixQuery(new Term(field, key));
        System.out.println(query.getClass());
        System.out.println(query.toString());
        System.out.println("--------------------------------");
    }

    //添加索引
    private void addDocument() throws Exception {
        //指定索引库存放路径
        Directory directory = getDirectory();

        //创建一个indexWriter对象
        IndexWriter indexWriter = getIndexWriter(directory);
        //创建一个Document对象
        Document document = new Document();
        //向document对象中添加域
        document.add(new StringField("fileName", "添加新的文档", Field.Store.YES));
        document.add(new TextField("fileContent", "添加新的文档内容", Field.Store.NO));

        //添加文档到索引库
        indexWriter.addDocument(document);
        //关闭indexWriter
        indexWriter.close();
    }

    //合并索引
    public void mergeIndex() {
        IndexWriter writer = null;
        Directory directory = null;
        try {
            directory = getDirectory();
            writer = getIndexWriter(directory);
            //获取读取流
            IndexReader reader = getIndexReader(directory);
            //合并文件夹
            writer.forceMerge(1);
            //提交
            writer.commit();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    //修改索引
    public boolean updateDocument(Term term, Document doc) throws IOException {
        //指定索引库存放路径
        Directory directory = getDirectory();

        //创建一个indexWriter对象
        IndexWriter indexWriter = getIndexWriter(directory);
        try {
            indexWriter.updateDocument(term, doc);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    //删除索引
    public boolean deleteDocument(Query query) throws IOException {
        //指定索引库存放路径
        Directory directory = getDirectory();

        //创建一个indexWriter对象
        IndexWriter indexWriter = getIndexWriter(directory);
        try {
            indexWriter.deleteDocuments(query);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    //直接清空索引
    public boolean deleteAll() throws IOException {
        //指定索引库存放路径
        Directory directory = getDirectory();

        //创建一个indexWriter对象
        IndexWriter indexWriter = getIndexWriter(directory);
        try {
            indexWriter.deleteAll();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 得到IndexReader对象
     *
     * @param directory
     *            文件夹对象
     * @return 返回一个可以使用的IndexReader对象
     * @throws IOException
     */
    public static IndexReader getIndexReader(Directory directory) throws IOException {
        IndexReader indexReader = DirectoryReader.open(directory);
        return indexReader;
    }


    /**
     * 获取Directory
     *
     *            传入文件夹路径
     * @return 返回一个Directory对象
     * @throws IOException
     */
    public static Directory getDirectory() throws IOException {
        String indexPath = BookUtil.INDEX_PATH;
        Directory directory = FSDirectory.open(Paths.get(indexPath));
        return directory;
    }

    /**
     * 得到IndexWriter对象
     *
     * @param directory
     *            传入directory文件夹对象
     * @return 返回可以使用，没有被close掉的IndexWriter对象
     * @throws IOException
     */
    public static IndexWriter getIndexWriter(Directory directory) throws IOException {
        // 中文分词器
        SmartChineseAnalyzer analyzer = new SmartChineseAnalyzer();
        // 索引配置
        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        // 获取索引实例
        IndexWriter indexWriter = new IndexWriter(directory, config);
        // 没有则new一个加入map
        return indexWriter;
    }

}
