package com.example.user.utils;

import com.example.user.domain.Result;
import com.example.user.enums.ResultEnum;

public class ResultUtil {
    public static<T> Result success(Integer code, String msg, T data) {
        Result<T> result = new Result<>();
        result.setCode(code);
        result.setMsg(msg);
        result.setData(data);
        return result;
    }

    public static<T> Result success(String msg, T data) {
        Result<T> result = new Result<>();
        result.setCode(ResultEnum.SUCCESS.getCode());
        result.setMsg(msg);
        result.setData(data);
        return result;
    }

    public static<T> Result success(T data) {
        Result<T> result = new Result<>();
        result.setCode(ResultEnum.SUCCESS.getCode());
        result.setMsg(ResultEnum.SUCCESS.getMsg());
        result.setData(data);
        return result;
    }

    public static<T> Result error(String msg) {
        Result<T> result = new Result<>();
        result.setCode(ResultEnum.ERROR.getCode());
        result.setMsg(msg);
        result.setData(null);
        return result;
    }
}
