package com.example.user.utils;

public class BookUtil {
    public static final String BOOK_PATH = "E:/shoucangshi/books-test";
    public static final String BOOK_PATH_CONTENT = "E:/shoucangshi/books-test/";
    public static final String INDEX_PATH = "E:/shoucangshi/index-path/testIndex";
    public static final String PIC_PATH = "E:/shoucangshi/pics/";
}
