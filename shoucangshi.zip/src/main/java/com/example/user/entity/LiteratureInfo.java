package com.example.user.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;

@Data
@Entity
public class LiteratureInfo {

    //收录编号
    @Id
    private String lrtId;

    //文献题目
    @NotEmpty(message = "文献题目不能为空")
    private String lrtTitle;

    //文献作者
    @NotEmpty(message = "文献作者不能为空")
    private String lrtAuthor;

    //文献图片
    private String lrtPic;

    //文献正文
    @NotEmpty(message = "文献正文内容不能为空")
    private String lrtContent;

    //收录日期
    private String lrtDate;

    //出版日期
    @NotEmpty(message = "出版日期不能为空")
    private String lrtLastDate;

    //收藏馆
    @NotEmpty(message = "收藏地址不能为空")
    private String lrtAddress;

    //分类
    @NotEmpty(message = "分类不能为空")
    private String lrtClassification;

    //出版年代
    @NotEmpty(message = "出版年代不能为空")
    private String lrtPublishAge;

    //是否删除字段
    private Integer isDeleted;

}
