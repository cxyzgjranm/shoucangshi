package com.example.user.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;

/**
 * @Author cxy
 * @Date 2021-11-3
 */

@Entity
@Data
public class UserInfo {
    //用户Id
    @Id
    private String userId;

    //用户昵称
    @NotEmpty(message = "姓名不能为空")
    private String userName;

    //用户密码（进行加密）
    @NotEmpty(message = "密码不能为空")
    private String userPassword;

    //用户手机号码
    @NotEmpty(message = "手机号码不能为空")
    private String userTelenum;

    //用户头像
    private String userPortrait;

    //用户注册日期
    private String userRegistdate;

    //用户最新登录日期
    private String userNewlogindate;

    //用户最后退出日期
    private String userLastsignoutdate;

    //逻辑删除字段
//    @TableLogic
//    @ApiModelProperty(value = "逻辑删除 1 表示已删除 0 表示未删除")
    private Integer isDeleted;

}

