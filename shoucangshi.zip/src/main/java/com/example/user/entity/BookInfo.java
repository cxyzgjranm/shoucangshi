package com.example.user.entity;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;

@Entity
@Data
public class BookInfo {

    //书的编号
    @Id
    private String bId;

    //书名
    @NotEmpty(message = "书名不能为空")
    private String bName;

    //书的存放位置
    @NotEmpty(message = "书的位置不能不填")
    private String bLocation;

    //丛书名
    @NotEmpty(message = "丛书名不能为空")
    private String bSeriesName;

    //责任者
    @NotEmpty(message = "作者不能为空")
    private String bAuthor;

    //责任者朝代
    private String bAuthorDynasty;

    //编著方式
    private String bEditingMethod;

    //出版年代
    @NotEmpty(message = "出版年代不能为空")
    private String bPublishAge;

    //出版者
    private String bPublisher;

    //分类
    @NotEmpty(message = "分类是什么")
    private String bClassification;

    //收藏馆
    @NotEmpty(message = "收藏地址不能为空")
    private String bAddress;

    //描述(简介)
    private String bDescription;

    //书的封面图片
    private String bPicture;

    //删除字段
    //数据库直接默认为未删除
    private Integer isDeleted;


}
