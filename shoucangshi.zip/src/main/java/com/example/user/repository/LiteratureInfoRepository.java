package com.example.user.repository;

import com.example.user.entity.LiteratureInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LiteratureInfoRepository extends JpaRepository<LiteratureInfo, String> {

    @Query(
            value = "select * from literature_info where is_deleted = 0",
            nativeQuery = true
    )
    List<LiteratureInfo> findAllInfo();

    @Query(
            value = "select * from literature_info where is_deleted = 0 and lrt_id = :id",
            nativeQuery = true
    )
    LiteratureInfo findByLrtId(@Param("id") String id);
}
