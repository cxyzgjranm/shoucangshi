package com.example.user.repository;

import com.example.user.entity.BookInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BookInfoRepository extends JpaRepository<BookInfo, String> {

    @Query(
            value = "select * from book_info where is_deleted = 0 and b_name like %:b_name%",
            nativeQuery = true
    )
    List<BookInfo> findByBName(@Param("b_name") String bookName);

    @Query(
            value = "select * from book_info where is_deleted = 0 and b_author like %:b_author%",
            nativeQuery = true
    )
    List<BookInfo> findByBAuthor(@Param("b_author") String bookAuthor);

    @Query(
            value = "select * from book_info where is_deleted = 0 and b_series_name like %:bSeriesName%",
            nativeQuery = true
    )
    List<BookInfo> findByBSeriesName(@Param("bSeriesName") String bookSeriesName);

    @Query(
            value = "select * from book_info where is_deleted = 0 and b_id = :b_id",
            nativeQuery = true)
    BookInfo findByBId(@Param("b_id") String bookId);

    @Query(
            value = "select * from book_info where is_deleted = 0",
            nativeQuery = true
    )
    List<BookInfo> findAllInfo();

    @Query(
            value = "select * from book_info where is_deleted = 0 and b_location = :b_location",
            nativeQuery = true
    )
    BookInfo findByBLocation(@Param("b_location") String location);


    @Query(
            value = "select * from book_info where is_deleted = 0 and b_classification = :sort",
            nativeQuery = true
    )
    List<BookInfo> findByBClassification(@Param("sort") String sort);
}
