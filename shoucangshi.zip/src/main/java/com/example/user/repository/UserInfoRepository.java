package com.example.user.repository;

import com.example.user.entity.UserInfo;
import com.example.user.pojo.UserPojo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface UserInfoRepository extends JpaRepository<UserInfo, String> {
    @Query(
            value = "select * from user_info where is_deleted = 0 and user_telenum = :phoneNum",
            nativeQuery = true
    )
    UserInfo findByUserTelenum(@Param("phoneNum") String phoneNum);
}
